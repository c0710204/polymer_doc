yuidoc-bootstrap-theme
======================

A revamped yuidoc theme with bootstrap